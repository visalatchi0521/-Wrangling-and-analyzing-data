# Data-wrangling-project

## Data Source:

The data was gathered from a given CSV, a website, and Twitter’s API. Tweepy was used to access the API and gather the JSON data for the tweets. The JSON data was stored in a text file, then loaded what is required into a pandas data frame.

## Process:

1. The quality and tidiness issues were identified.
2. A copy was created for each dataset before cleaning.
3. The issues were fixed data was cleaned.
4. The cleaned data was saved.
5. The dataset was explored using data visualization.

## Conclusion:
1. Pupper have the highest count in the data and Doggo & Floofer the least.
2. Retweet_count and favorite_count are positively correlated.
3. The overall rating is almost in the same range for all stages with pupper in lower end and doggo,floofer and puppo in higher end.
4. One could observe that mostly, irrespective of the time the rating given is 12. 
